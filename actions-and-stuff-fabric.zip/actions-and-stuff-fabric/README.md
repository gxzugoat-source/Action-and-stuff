# Actions Fabric (client-side)
Bedrock "Actions & Stuff"-style player animations for Fabric 1.21.11.

## Build
1. Generate a template at https://fabricmc.net/develop (MC 1.21.11, Mojang mappings)
   and copy its `gradlew`, `gradlew.bat`, `gradle/` folder into this project.
   Update versions in gradle.properties from that page.
2. Run `./gradlew build`
3. Jar: `build/libs/actions-fabric-1.0.0.jar` -> put in `.minecraft/mods`
   (needs Fabric API).

## Note
Written without a compiler. If Mojang-mapped field names differ slightly in 1.21.11,
fix them in `HumanoidModelMixin.java` (compiler errors will point to the line).
